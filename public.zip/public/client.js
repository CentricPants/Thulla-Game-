const socket = io();
let gameState = null;
let localId = null;
// --- SOUND MANAGER ---
const sounds = {
    bg: new Audio('bg_theme.mp3'),
    place: new Audio('card_place.mp3'),
    shuffle: new Audio('shuffling.mp3'),
    collect: new Audio('collect.mp3'),
    alert: new Audio('alert.mp3')
};

// Settings
sounds.bg.loop = true;
sounds.bg.volume = 0.3; // Lower volume for background
let musicEnabled = false;

function toggleMusic() {
    musicEnabled = !musicEnabled;
    const btn = document.getElementById('music-btn');
    if (musicEnabled) {
        sounds.bg.play().catch(e => console.log("Interaction needed first"));
        btn.innerText = "🎵 Music: ON";
        btn.style.background = "#4CAF50";
    } else {
        sounds.bg.pause();
        btn.innerText = "🎵 Music: OFF";
        btn.style.background = "#666";
    }
}

function playSfx(name) {
    if (!sounds[name]) return;
    // Clone node allows playing same sound fast (overlapping)
    const sfx = sounds[name].cloneNode();
    sfx.volume = 0.6;
    sfx.play().catch(() => {});
}
// --- CONNECT ---
socket.on('connect', () => {
    localId = socket.id;
    console.log("Connected as:", localId);
});

// --- LOBBY ACTIONS ---
function createGame() {
    const name = document.getElementById('host-name').value || "Host";
    socket.emit('create-game', { name }, (res) => {
        if (res.success) console.log("Game Created:", res.gameId);
    });
}

function joinGame() {
    const name = document.getElementById('player-name').value || "Player";
    const gid = document.getElementById('game-id').value;
    socket.emit('join-game', { name, gameId: gid }, (res) => {
        if (!res.success) alert(res.message);
    });
}

function startGame() {
    socket.emit('start-game', (res) => {
        if (res && !res.success) alert(res.message);
    });
}

// --- STATE HANDLER ---
socket.on('game-state', (state) => {
    gameState = state;
    updateInterface();
});

socket.on('game-started', () => {

    playSfx('shuffle');
    if(gameState) {
        gameState.gameStarted = true; 
        updateInterface();
    }
});
// --- GAME OVER HANDLER ---
socket.on('game-over', (data) => {
    // 1. Hide Game Screen
    document.getElementById('game-screen').classList.remove('active');
    document.getElementById('game-screen').classList.add('hidden');
    
    // 2. Show Game Over Screen
    const screen = document.getElementById('game-over-screen');
    screen.classList.remove('hidden');
    screen.classList.add('active');
    screen.style.display = 'flex';

    // 3. Update Rankings
    const list = document.getElementById('rankings-list');
    list.innerHTML = '';
    
    // Add Winners
    data.winners.forEach((name, i) => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>#${i + 1}</strong> ${name} (Winner)`;
        list.appendChild(li);
    });

    // Add Loser
    if (data.loser) {
        const li = document.createElement('li');
        li.style.color = '#ff6b6b';
        li.innerHTML = `<strong>Loser:</strong> ${data.loser} 🤡`;
        list.appendChild(li);
    }
});

function resetToLobby() {
    location.reload(); // Simple reload to reset everything
}

// --- UI UPDATER ---
function updateInterface() {
    if (!gameState) return;

    const lobbyScreen = document.getElementById('waiting-screen');
    const gameScreen = document.getElementById('game-screen');
    const lobbySetup = document.getElementById('lobby-screen');

    // Hide all
    [lobbySetup, lobbyScreen, gameScreen].forEach(el => {
        el.classList.remove('active');
        el.classList.add('hidden');
    });

    if (gameState.gameStarted) {
        gameScreen.classList.remove('hidden');
        gameScreen.classList.add('active');
        renderGameBoard();
    } else {
        lobbyScreen.classList.remove('hidden');
        lobbyScreen.classList.add('active');
        renderLobby();
    }
}

// --- RENDERERS ---
function renderLobby() {
    document.getElementById('game-id-display-small').innerText = gameState.roomId;
    const grid = document.getElementById('players-grid');
    grid.innerHTML = '';
    
    gameState.players.forEach((p, i) => {
        const div = document.createElement('div');
        div.className = `player-card-waiting ${i === 0 ? 'host' : ''}`;
        div.innerHTML = `<div style="font-size:2rem;">👤</div><div style="font-weight:bold; color:white;">${p.name}</div>`;
        grid.appendChild(div);
    });

    const startBtn = document.getElementById('start-game-btn');
    if (gameState.players.length > 0 && gameState.players[0].id === localId) {
        startBtn.disabled = false;
        startBtn.innerText = "Start Game";
    } else {
        startBtn.disabled = true;
        startBtn.innerText = "Waiting for Host...";
    }
}

function renderGameBoard() {
    // 1. OPPONENTS
    const oppContainer = document.getElementById('opponents-container');
    oppContainer.innerHTML = '';
    gameState.players.forEach(p => {
        if (p.id !== localId) {
            const div = document.createElement('div');
            div.id = `opponent-${p.id}`; 
            div.className = `opponent-card ${p.id === gameState.currentPlayerId ? 'current' : ''}`;
            div.innerHTML = `<div class="opponent-name">${p.name}</div><div style="color:#aaa;">${p.cardCount} cards</div>`;
            oppContainer.appendChild(div);
        }
    });

    // 2. MY HAND
    renderMyHand();

    // 3. TABLE
    const tableDiv = document.getElementById('game-center');
    if (gameState.table.length === 0) {
        if(!document.querySelector('.thrown') && !document.querySelector('.flying-pickup')) {
             tableDiv.innerHTML = ''; 
        }
    } 
    else {
        gameState.table.forEach((card, index) => {
            const exists = document.getElementById(`table-card-${card.id}`);
            if (!exists) {
                const el = createCardElement(card);
                el.id = `table-card-${card.id}`; 
                el.style.position = 'absolute';
                el.style.setProperty('--i', index); 
                el.style.transform = `rotateZ(${Math.random() * 30 - 15}deg)`;
                tableDiv.appendChild(el);
            } else {
                if (exists.parentElement === tableDiv) {
                    exists.style.setProperty('--i', index);
                }
            }
        });
    }

    // 4. STATUS & SOUND ALERT (FIXED LOGIC)
    const statusEl = document.getElementById('status-text');
    const turnPlayer = gameState.players.find(p => p.id === gameState.currentPlayerId);
    
    if (turnPlayer) {
        // Update Text
        if (turnPlayer.id === localId) {
            statusEl.innerText = "YOUR TURN";
            statusEl.style.color = "#FFD700";
        } else {
            statusEl.innerText = `${turnPlayer.name}'s Turn`;
            statusEl.style.color = "white";
        }

        // --- SOUND LOGIC FIX ---
        // Only play if the turn JUST changed to me
        if (turnPlayer.id === localId && lastTurnPlayerId !== localId) {
            playSfx('alert');
        }
        
        // Update the tracker
        lastTurnPlayerId = turnPlayer.id;
    }
}

function sortHand(hand) {
    const rankValues = {
        '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
        'jack': 11, 'queen': 12, 'king': 13, 'ace': 14
    };
    const suitOrder = { 'spades': 4, 'hearts': 3, 'clubs': 2, 'diamonds': 1 };
    return hand.sort((a, b) => {
        if (suitOrder[a.suit] !== suitOrder[b.suit]) return suitOrder[b.suit] - suitOrder[a.suit];
        return rankValues[b.rank] - rankValues[a.rank];
    });
}

function renderMyHand() {
    const container = document.getElementById('player-hand');
    container.innerHTML = '';

    const me = gameState.players.find(p => p.id === localId);
    if (!me) return;

    const sortedHand = sortHand(me.hand);
    const isMyTurn = (me.id === gameState.currentPlayerId);
    let validSuit = null;
    if (isMyTurn && gameState.table.length > 0) {
        const leadSuit = gameState.table[0].suit;
        if (me.hand.some(c => c.suit === leadSuit)) validSuit = leadSuit;
    }

    const overlap = sortedHand.length > 8 ? -50 : -30;
    
    sortedHand.forEach((card, i) => {
        const el = createCardElement(card);
        el.id = `hand-card-${card.id}`;
        el.style.marginLeft = i === 0 ? '0px' : `${overlap}px`;

        let isValid = false;
        if (isMyTurn) {
            if (!validSuit) isValid = true; 
            else if (card.suit === validSuit) isValid = true; 
        }

        if (isValid) {
            el.classList.add('valid');
            el.onclick = () => playCard(card);
        } else {
            el.classList.add('invalid');
        }
        
        container.appendChild(el);
    });
}

function createCardElement(card) {
    const div = document.createElement('div');
    div.className = 'card';
    const front = document.createElement('div');
    front.className = 'card-face face-front';
    const img = document.createElement('img');
    img.src = `${card.suit}_${card.rank}.png`;
    img.onerror = () => { img.style.display='none'; front.innerText = `${card.rank}\n${card.suit}`; front.style.color = 'black'; front.style.display='flex'; front.style.justifyContent='center'; front.style.alignItems='center'; };
    front.appendChild(img);
    const back = document.createElement('div');
    back.className = 'card-face face-back';
    const imgBack = document.createElement('img');
    imgBack.src = 'jack_back.png';
    back.appendChild(imgBack);
    div.appendChild(front);
    div.appendChild(back);
    return div;
}

function playCard(card) {
    socket.emit('play-card', { card }, (res) => {
        if (!res.success) alert(res.message);
    });
}

// --- ANIMATION EVENTS ---
socket.on('player-action', (data) => {
    if (data.type === 'play') {
        animateThrow(data.playerId, data.card);
    }
});

socket.on('round-end', (data) => {
    const tableDiv = document.getElementById('game-center');
    const cards = Array.from(tableDiv.children);
    playSfx('collect');
    if (data.type === 'thulla') {
        // Pass the Victim ID (The person picking up cards)
        animateToTarget(cards, data.victimId);
    } else {
        animateToDiscard(cards);
    }
});

// --- HELPER: FIND PLAYER POSITION ---
function getPlayerRect(playerId) {
    if (playerId === localId) {
        // My Hand
        const hand = document.getElementById('player-hand');
        if (hand) return hand.getBoundingClientRect();
    } else {
        // Opponent Card
        const opp = document.getElementById(`opponent-${playerId}`);
        if (opp) return opp.getBoundingClientRect();
    }
    // Fallback: Top center
    return { left: window.innerWidth / 2 - 50, top: 50, width: 100, height: 100 };
}

// --- ANIMATION FUNCTIONS ---

function animateThrow(playerId, card) {
    // Hide original card in hand immediately
    playSfx('place');
    if (playerId === localId) {
        const cardInHand = document.getElementById(`hand-card-${card.id}`);
        if (cardInHand) cardInHand.style.opacity = '0';
    }

    // Create Clone
    const el = createCardElement(card);
    el.classList.add('thrown');
    el.id = `table-card-${card.id}`; 
    document.body.appendChild(el);
    
    const table = document.getElementById('game-center');
    const tableRect = table.getBoundingClientRect();
    const destX = tableRect.left + tableRect.width/2 - 60;
    const destY = tableRect.top + tableRect.height/2 - 84;
    
    // Get Start Position
    let startRect = getPlayerRect(playerId);
    let startX = startRect.left + startRect.width / 2 - 60;
    let startY = startRect.top;

    el.style.setProperty('--startX', `${startX}px`);
    el.style.setProperty('--startY', `${startY}px`);
    el.style.setProperty('--moveX', `${destX - startX}px`);
    el.style.setProperty('--moveY', `${destY - startY}px`);
    el.style.setProperty('--randomRot', `${Math.random()*20-10}deg`);

    setTimeout(() => {
        el.classList.remove('thrown');
        if(document.getElementById('game-center')) {
             document.getElementById('game-center').appendChild(el);
             el.style.position = 'absolute';
             const newIndex = document.getElementById('game-center').children.length - 1;
             el.style.setProperty('--i', newIndex);
             el.style.transform = `rotateZ(${Math.random()*20-10}deg)`;
             el.style.left = 'auto'; el.style.top = 'auto';
        }
    }, 800);
}

function animateToTarget(cards, targetId) {
    // 1. Get Target Coordinates (Victim)
    const targetRect = getPlayerRect(targetId);
    const destX = targetRect.left + targetRect.width / 2 - 60;
    const destY = targetRect.top + 20;

    cards.forEach((c, i) => {
        // Mark as animating
        c.classList.add('flying-pickup');
        
        // Stagger animations (One after another)
        setTimeout(() => {
            c.style.transition = 'all 0.6s cubic-bezier(0.25, 0.8, 0.25, 1)';
            c.style.position = 'fixed'; 
            
            // Lock current position before flying
            const rect = c.getBoundingClientRect();
            c.style.left = rect.left + 'px';
            c.style.top = rect.top + 'px';
            c.style.transform = 'scale(1)'; // Reset any rotation/scale
            
            // Trigger reflow
            void c.offsetWidth;
            
            // Fly to Target
            c.style.left = destX + 'px';
            c.style.top = destY + 'px';
            c.style.transform = 'scale(0.5) rotate(180deg)'; // Shrink and flip
            c.style.opacity = 0;
            
        }, i * 150); // 150ms delay between cards
    });

    // Cleanup after all animations done
    setTimeout(() => { 
        document.getElementById('game-center').innerHTML = ''; 
    }, cards.length * 150 + 600);
}

function animateToDiscard(cards) {
    const discard = document.getElementById('discard-pile');
    if(!discard) return;
    const dest = discard.getBoundingClientRect();
    
    cards.forEach((c, i) => {
        setTimeout(() => {
            c.style.transition = 'all 0.5s ease-in-out';
            c.style.position = 'fixed'; 
            const rect = c.getBoundingClientRect();
            c.style.left = rect.left + 'px';
            c.style.top = rect.top + 'px';
            
            c.innerHTML = '';
            c.className = 'discarded-card'; 

            void c.offsetWidth;
            
            c.style.left = (dest.left + 10) + 'px';
            c.style.top = (dest.top + 10) + 'px';
            c.style.transform = `scale(0.8) rotateZ(${Math.random()*20-10}deg)`;
            c.style.opacity = 0;
        }, i * 50);
    });

    setTimeout(() => { 
        document.getElementById('game-center').innerHTML = ''; 
        cards.forEach(() => {
            const d = document.createElement('div');
            d.className = 'discarded-card';
            d.style.position = 'absolute';
            d.style.transform = `rotateZ(${Math.random()*10-5}deg)`;
            discard.appendChild(d);
        });
        while(discard.children.length > 20) discard.removeChild(discard.firstChild);
    }, 1000);
}

// --- MENU HELPERS ---
function showCreateGame() { 
    document.querySelector('.lobby-mode').style.display = 'none'; 
    document.getElementById('create-game-form').classList.remove('hidden'); 
}
function showJoinGame() { 
    document.querySelector('.lobby-mode').style.display = 'none'; 
    document.getElementById('join-game-form').classList.remove('hidden'); 
}
function resetLobby() { 
    document.getElementById('create-game-form').classList.add('hidden'); 
    document.getElementById('join-game-form').classList.add('hidden');
    document.querySelector('.lobby-mode').style.display='flex';
}